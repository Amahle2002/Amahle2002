/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;


/**
 *
 * @author gabri
 */
public class ShowStudent 
{
    
    public static void ShowStudentMethod()
    {       
        Student s = new Student(); // Instaiating the student class/ s is the variable used to call methods in the class
        s.getId();
        s.getCreditHours();
        s.getPointsEarned();
        s.getGradePointAverage();
        s.getAllDetails();
    }
    
    
}
