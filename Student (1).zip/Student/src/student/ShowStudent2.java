/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import static student.Student.CreditHours;
import static student.Student.GradePointAverage;
import static student.Student.IdNumber;
import static student.Student.PointsEarned;

/**
 *
 * @author gabri
 */
public class ShowStudent2 {
    
    public static String IdNumber="9999";
    public static double CreditHours=3;
    public static double PointsEarned=12;
    public static double GradePointAverage; 
    
    
     public static void ShowAllDetails()
    {       
        GradePointAverage = PointsEarned/CreditHours;
        
        System.out.print("-------------------------------------------------"+"\n"+
                         "Detailed Summary"+"\n"+
                         "-------------------------------------------------"+"\n"+
                         "ID number: "+IdNumber+"\n"+
                         "Credit Hours: "+CreditHours+"\n"+
                         "Points Earned: "+PointsEarned+"\n"+
                         "GradePointAverage is: "+GradePointAverage+"\n"+
                         "---------------------------------------------------");
    }
    
}
