/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.util.Scanner;

/**
 *
 * @author gabri
 */
public class Student {

    public static Scanner Keyboard = new Scanner(System.in);
    public static String IdNumber;
    public static double CreditHours;
    public static double PointsEarned;
    public static double GradePointAverage;
    
    public static void main(String[] args) {
        // TODO code application logic here
//        getId();
//        getCreditHours();
//        getPointsEarned();
//        getGradePointAverage();
//        getAllDetails();
//        ShowStudent ssm = new ShowStudent(); // Instaiating the student class/ ssm is the variable used to call methods in the class
//        ssm.ShowStudentMethod();
        
        ShowStudent2 ssm2 = new ShowStudent2(); // Instaiating the student class/ ssm is the variable used to call methods in the class
        ssm2.ShowAllDetails();
    }
    public static void getId()
    {
        System.out.println("Please enter your ID: ");
        IdNumber = Keyboard.nextLine();
    }
    public static void getCreditHours()
    {
        System.out.print("Enter the Credit Hours: ");
        CreditHours = Keyboard.nextDouble();
    }
    public static void getPointsEarned()
    {
        System.out.print("Enter the Points Earned: ");
        PointsEarned = Keyboard.nextDouble();
    }
     public static void getGradePointAverage()
    {       
        GradePointAverage = PointsEarned/CreditHours;
    }
     public static void getAllDetails()
    {       
        System.out.print("-------------------------------------------------"+"\n"+
                         "Detailed Summary"+"\n"+
                         "-------------------------------------------------"+"\n"+
                         "ID number: "+IdNumber+"\n"+
                         "Credit Hours: "+CreditHours+"\n"+
                         "Points Earned: "+PointsEarned+"\n"+
                         "GradePointAverage is: "+GradePointAverage+"\n"+
                         "---------------------------------------------------");
    }
}
